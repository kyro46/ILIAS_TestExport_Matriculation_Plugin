<?php
$id                = 'texpmatriculation';
$version           = '0.0.1';
$ilias_min_version = '4.4.0';
$ilias_max_version = '4.4.999';
$responsible       = 'Christoph Jobst';
$responsible_mail  = 'cjobst@wifa.uni-leipzig.de';